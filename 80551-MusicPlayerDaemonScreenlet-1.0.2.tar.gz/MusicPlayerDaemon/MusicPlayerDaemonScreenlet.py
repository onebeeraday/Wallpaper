#! /usr/bin/env python

# -------------------------------------LICENCE------------------------------------
# This application is released under the GNU General Public License v3 (or, at
# your option, any later version). You can find the full text of the license
# under http://www.gnu.org/licenses/gpl.txt.
# By using, editing and/or distributing this software you agree to the terms
# and conditions of this license.
# Thank you for using free software!
# --------------------------------------------------------------------------------


# MusicPlayerDaemon Screenlet (c) Krzysztof Magusiak <chrmag@poczta.onet.pl>

# Changelog:
# - 0.1:
#   Initial player (basic controls)
# - 0.2:
#   Interface optimization (faster and more personnalizable)
#   Playlist view (with jump function, delete function [using del key])
# - 0.2.1:
#   Filtering of added files to the playlist (may be enabled in options)
#   Cleaning the playlist
# - 0.2.2
#   Sorting the playlist
# - 0.2.3
#   Adding files from the library
#   Moving files inside the playlist (arrows + Ctrl)
#   Some bugs are corrected
# - 1.0
#   Connecting to MPD server using a socket (mpc is no more required)
#   Coverart (using Amazon)
#   Scroll inside the playlist using the mouse wheel
#   Selecting the current song based on the index
#   Enhanced adding files from library box
#   Enhanced personalizable interface
#   Playlist scroller
#   XML menu
# - 1.0.1
#   Fix: default theme was not loading on first start
# - 1.0.2
#   Fix: was not connecting without password

from string import Template
import screenlets
from screenlets.options import StringOption, BoolOption, IntOption, FontOption, ColorOption
from screenlets import DefaultMenuItem, Plugins
import cairo
import gc
import gobject
import gtk
import os
import pango
import re
import rsvg
import socket
#import time #debugging: [time.clock()]
import xml.dom.minidom

# Default CoverSearch plugin (was not working [when I was creating this script])
#CoverSearch = Plugins.importAPI('CoverSearch')
CoverSearch = __import__('AmazonCover')


# Some basic functions

def htmlentities(s):
	"""Escape some of the html entities"""
	out = ''
	for c in s:
		if c == '&': c = '&amp;'
		elif c == '<': c = '&lt;'
		elif c == '>': c = '&gt;'
		out += c
	return out
def htmlremovelastchars(s, times = 1):
	"""Removes last printed characters from a HTML string"""
	if times < 1 or len(s) < 1: return s
	c = s[-1]
	if c == '>':
		p = s.rfind('<')
		if p == -1: raise Exception, 'Invalid string!'
		mclose = s[p:]
		mopen = mclose[0] + mclose[2:]
		p = s.rfind(mopen)
		if p == -1: raise Exception, 'Invalid string!'
		text = s[p:]
		text = text[len(mopen):-len(mclose)]
		text = htmlremovelastchars(text)
		if text != "": text = mopen + text + mclose
		s = s[:p] + text
	else:
		if c == ';' and s.rfind('&', -5):
			s = s[:s.rfind('&', -5)]
		if (len(s) <= 1): s = ""
		else: s = s[:-1]
	return htmlremovelastchars(s, times - 1)

def get_text_size(drawable, ctx, text, font, size, width = 9999, weight = 0, isHTML = True):
	"""Returns the line count of a given text"""
	if text == '': return ((0, 0), (0, 0), 0, (0, 0))
	ctx.save()
	if drawable.p_layout == None:
		drawable.p_layout = ctx.create_layout()
	else:
		ctx.update_layout(drawable.p_layout)
	if drawable.p_fdesc == None:
		drawable.p_fdesc = pango.FontDescription()
	drawable.p_fdesc.set_family_static(font)
	drawable.p_fdesc.set_size(size * pango.SCALE)
	drawable.p_fdesc.set_weight(weight)
	drawable.p_layout.set_font_description(drawable.p_fdesc)
	drawable.p_layout.set_width(width * pango.SCALE)
	if isHTML: drawable.p_layout.set_markup(text)
	else: drawable.p_layout.set_text(text)
	ctx.restore()
	extents, lextents = drawable.p_layout.get_pixel_extents()
	lines = drawable.p_layout.get_line_count()
	return ((extents[2], extents[3]), (lextents[2], lextents[3]), lines, ((extents[2] + lextents[2]) / 2, (extents[3] + lextents[3]) / 2))

def fix_text_render_on_line(drawable, ctx, text, font, size, width, weight = 0, isHTML = True):
	"""Strips the text, so it can be printed on a single line"""
	if get_text_size(drawable, ctx, text, font, size, width, weight, isHTML)[2] > 1:
		while get_text_size(drawable, ctx, text + '...', font, size, width, weight, isHTML)[2] > 1:
			stripped = False
			if isHTML:
				try:
					text = htmlremovelastchars(text)
					stripped = True
				except: pass
			if not stripped: text = text[:-1]
		text += '...'
	return text

def empty_function(p1 = None): pass

# Interface management

class ciEvent():
	"""Interface event"""
	
	source = None
	action = ''
	button = 0
	x      = 0
	y      = 0
	time   = 0
	
	def __init__(self, source = None):
		self.source = source
		self.time   = int(gobject.get_current_time() * 1000)

class ciObject():
	"""Interface object"""
	
	x          = 0
	y          = 0
	eventPaint = None # function(slet, ctx)
	_back      = False
	def canPaint(self, type): #Type: 0: no bg; 1: all; 2: bg
		"""Whether the object can be painted"""
		return (type != 0 or not self._back) and (type != 2 or self._back)
	
	def paint(self, slet, ctx, type = 0):
		"""Paints the object"""
		if self.canPaint(type) and self.eventPaint:
			ctx.save()
			ctx.translate(self.x, self.y)
			self.eventPaint(slet, ctx)
			ctx.restore()

class ciText(ciObject):
	"""Interface text"""
	
	text     = ''
	color    = [0, 0, 0, 1]
	font     = ''
	size     = 10
	width    = 9999
	align    = pango.ALIGN_LEFT
	line     = True
	template = None
	
	def __init__(self, text, x = 0, y = 0, color = [0, 0, 0, 1], font = '', size = 10, width = 9999, align = pango.ALIGN_LEFT, line = True, template = None):
		self.text     = text
		self.x        = x
		self.y        = y
		self.color    = color
		self.font     = font
		self.size     = int(size)
		self.width    = int(width)
		self.align    = align
		self.line     = line
		self.template = template
	
	def canPaint(self, type):
		return self.text != '' and ciObject.canPaint(self, type)

	def paint(self, slet, ctx, type = 0):
		if not self.canPaint(type): return
		ctx.save()
		ctx.set_source_rgba(self.color[0], self.color[1], self.color[2], self.color[3])
		text = self.text
		if self.template: text = self.template.applyTo(text)
		if self.line: text = fix_text_render_on_line(slet, ctx, text, self.font.rstrip(' 1234567890'), self.size, self.width)
		slet.draw_text(ctx, text, self.x, self.y, self.font.rstrip(' 1234567890'), self.size, self.width, self.align)
		ctx.restore()

class ciTemplate():
	"""Interface template"""
	
	items = {}
	
	def __init__(self):
		pass
	
	def getValue(self, name):
		try: return self.items[str(name)]
		except: return None
	
	def setValue(self, name, value, toHTML = True):
		if self.items == None: self.items = {}
		value = str(value)
		if toHTML: value = htmlentities(value)
		self.items[str(name)] = value
	
	def applyTo(self, text, isHTML = True):
		"""Applies this template to a string"""
		text = str(text)
		if self.items == None or text.find("$") == -1: return text
		return Template(text).safe_substitute(self.items)

class ciButton(ciObject):
	"""Interface button or image"""
	
	src        = ''
	srcOver    = ''
	img        = None
	imgOver    = None
	width      = -1
	height     = -1
	_mouseOver = False
	_toPaint   = False
	action     = ''
	pre_aspect = False
	eventClick = None # function(ciEvent)
	
	def __init__(self, src = '', action = ''):
		self.src = src
		self.action = action
	
	def __setattr__(self, name, value):
		self.__dict__[name] = value
		# Reset the image hander when the source has changed
		if name == 'src': self.img = None
		elif name == 'srcOver': self.imgOver = None
	
	def isOver(self, x ,y):
		"""Checks if (x,y) is over this image or button"""
		over = x >= self.x and x <= self.x + self.width and y >= self.y and y <= self.y + self.height
		if over != self._mouseOver:
			self._mouseOver = over
			self._toPaint = self._toPaint or self.srcOver != ''
		return self._mouseOver
	
	def getImage(self, slet, src):
		"""Gets an image handler for the image name"""
		if src == '': return None
		img = None
		type = 'svg'
		if slet.theme.has_key(src + '.svg'):
			img = slet.theme[src + '.svg']
		else: #Try to paint the image (even if it is not in the theme)
			if os.path.isabs(src): path = src
			else: path = os.path.join(slet.theme.path, src)
			if not os.path.isfile(path): path += '.svg' # default extension?
			if os.path.isfile(path):
				if path[-4:] == ".svg":
					try:
						f = open(path, "r")
						img = rsvg.Handle(data = f.read())
						f.close()
					except: img = None
				elif path[-4:] == ".jpg":
					img = gtk.gdk.pixbuf_new_from_file(path)
					type = 'jpg'
				elif path[-4:] == ".png":
					img = cairo.ImageSurface.create_from_png(path)
					type = 'png'
		if img != None: return (img, type)
		return None
	
	def paint(self, slet, ctx, type = 0):
		"""Paints this image or button"""
		self._toPaint = False
		if not self.canPaint(type):
			return
		if self.src == '':
			ciObject.paint(self, slet, ctx)
			return
		img = None
		if self._mouseOver and self.srcOver != '':
			if self.imgOver == None:
				self.imgOver = self.getImage(slet, self.srcOver)
			img = self.imgOver
		if img == None:
			if self.img == None:
				self.img = self.getImage(slet, self.src)
			img = self.img
		if not (img == None or self.width == 0 or self.height == 0):
			if img[1] == 'svg': size = img[0].get_dimension_data()
			else: size = [img[0].get_width(), img[0].get_height()]
			if not size: return
			if self.width < 0: scx = 1.0
			else: scx = float(self.width) / size[0]
			if self.height < 0: scy = 1.0
			else: scy = float(self.height) / size[1]
			if self.pre_aspect: scx = scy = min(scx, scy)
			ctx.save()
			ctx.translate(self.x, self.y)
			ctx.scale(scx, scy)
			if img[1] == 'svg': img[0].render_cairo(ctx)
			else:
				try:
					if img[1] == 'jpg': ctx.set_source_pixbuf(img[0], 0, 0)
					elif img[1] == 'png': ctx.set_source_surface(img[0], 0, 0)
					ctx.rectangle(0, 0, size[0], size[1])
					ctx.fill()
				except: pass
			ctx.restore()

	def mouse_click(self, x, y, button):
		"""Executes the event if (x,y) is over this image or button"""
		if self.eventClick != None and self.isOver(x, y):
			ev = ciEvent(self)
			ev.action = self.action
			ev.button = button
			ev.x      = x
			ev.y      = y
			self.eventClick(ev)
			return True
		return False

class ciGroup(ciButton):
	"""Interface group of ci* objects"""
	
	items = None
	
	def __init__(self, x = 0, y = 0, elements = 0):
		self.x = x
		self.y = y
		while elements > 0:
			self.add_ci(None)
			elements -= 1
	
	def add_ci(self, ci):
		if self.items == None: self.items = [ci]
		else: self.items.append(ci)
		return ci
	
	def __getitem__(self, i):
		return self.items[i]
	
	def __setitem__(self, i, val):
		self.items[i] = val
	
	def canPaint(self, type):
		return not self._back or type > 0
	
	def paint(self, slet, ctx, type = 0):
		self._toPaint = False
		if self.items == None or len(self.items) == 0 or not self.canPaint(type):
			return
		if self._back:
			type = 1
		ctx.save()
		ctx.translate(self.x, self.y)
		for i in self.items:
			if i != None:
				i.paint(slet, ctx, type)
		ctx.restore()
	
	def isOver(self, x, y):
		if self.items == None or len(self.items) == 0:
			return False
		over = False
		x -= self.x
		y -= self.y
		for i in self.items:
			try:
				if i.isOver(x, y): over = True
				if i._toPaint: self._toPaint = True
			except AttributeError:
				pass
		return over
	
	def mouse_click(self, x, y, button):
		if self.items == None or len(self.items) == 0:
			return False
		x -= self.x
		y -= self.y
		clicked = False
		for i in self.items:
			has_click_method = False
			try: has_click_method = i.mouse_click != None
			except AttributeError: pass
			if has_click_method and i.mouse_click(x, y, button): clicked = True
		return clicked

class MPDAddFrame():
	"""Add files from library dialog"""
	
	TYPES   = ['Any', 'Artist', 'Album', 'Title', 'Track', 'Name', 'Genre', 'Date', 'Comment', 'FileName']
	_parent = None
	_wnd    = None
	_tree   = None
	type    = "any"
	seek    = ""
	
	def __init__(self, parent):
		SPACING = 5
		self._parent = parent
		self._wnd = wnd = gtk.Window(gtk.WINDOW_TOPLEVEL)
		wnd.set_size_request(380, 450)
		wnd.set_title("MPD Add...")
		wnd.set_resizable(True)
		wnd.set_modal(True)
		wnd.connect("delete_event", self.on_close)
		
		mainbox = gtk.VBox(False, SPACING)
		wnd.set_border_width(SPACING)
		wnd.add(mainbox)
		mainbox.show()
		
		filterbox = gtk.HBox(False, SPACING)
		labFilter = gtk.Label("Filter:")
		cmbFilter = gtk.combo_box_new_text()
		for item in self.TYPES:
			cmbFilter.append_text(item)
		cmbFilter.set_active(0)
		cmbFilter.connect("changed", self.on_filter_type_change)
		txtFilter = gtk.Entry()
		txtFilter.set_text(self.seek)
		txtFilter.set_max_length(50)
		txtFilter.connect("changed", self.on_filter_text_change)
		filterbox.pack_start(labFilter)
		filterbox.pack_start(cmbFilter, False)
		filterbox.pack_start(txtFilter)
		mainbox.pack_start(filterbox, False)
		filterbox.show()
		labFilter.show()
		cmbFilter.show()
		txtFilter.show()
		
		model = gtk.TreeStore(gobject.TYPE_STRING)
		self._tree = viewList = gtk.TreeView(model)
		viewList.get_selection().set_mode(gtk.SELECTION_MULTIPLE)
		modelCol = gtk.TreeViewColumn("File")
		renderer = gtk.CellRendererText()
		modelCol.pack_start(renderer, False)
		modelCol.add_attribute(renderer, 'text', 0)
		viewList.append_column(modelCol)
		viewListScroll = gtk.ScrolledWindow()
		viewListScroll.add(viewList)
		mainbox.pack_start(viewListScroll)
		viewList.show()
		viewListScroll.show()
		
		cmdalign = gtk.Alignment(1.0)
		cmdbox = gtk.HBox(True, SPACING)
		cmdAdd = gtk.Button("Add", gtk.STOCK_ADD)
		cmdAdd.connect("clicked", self.on_add)
		cmdbox.pack_start(cmdAdd)
		cmdAdd.show()
		cmdClose = gtk.Button("Close", gtk.STOCK_CLOSE)
		cmdClose.connect("clicked", self.on_close)
		cmdbox.pack_start(cmdClose)
		cmdClose.show()
		cmdalign.add(cmdbox)
		cmdbox.show()
		mainbox.pack_start(cmdalign, False)
		cmdalign.show()
	
	def setVisible(self, visible):
		if visible:
			self._wnd.show()
			self.refresh_list()
		else: self._wnd.hide()
	
	def get_selected_files(self):
		"""Gets the selected files"""
		list = []
		try:
			select = self._tree.get_selection().get_selected_rows()
			if select:
				for path in select[1]:
					list.append(select[0].get_value(select[0].get_iter(path), 0))
		except:
			list = None
		return list
	
	def refresh_list(self):
		"""Refreshes the list"""
		if self._tree and self._parent:
			model = self._tree.get_model()
			list = self._parent.mpd.request_search(self.seek, self.type)
			model.clear()
			if list:
				for song in list:
					model.append(None, [song["file"]])
	
	def on_filter_type_change(self, cmb):
		try:
			model = cmb.get_model()
			active = cmb.get_active()
			if active < 0:
				raise Exception, 'None type selected'
			self.type = model[active][0].lower()
		except:
			self.type = self.TYPES[0].lower()
		self.refresh_list()
	
	def on_filter_text_change(self, txt):
		self.seek = txt.get_text()
		self.refresh_list()
	
	def on_add(self, obj):
		selection = self.get_selected_files()
		if selection:
			count = 0
			cmd = "command_list_begin\n"
			for song in selection:
				cmd += 'add "' + song + '"\n'
				count += 1
			cmd += "command_list_end"
			self._parent.mpd.send_command(cmd)
			if count > 0:
				self._parent._playlist_update = 0
				self._parent.update()
				self.on_close(obj)
	
	def on_close(self, obj, param = None):
		self._wnd.hide()
		self._wnd.destroy()

class MPDControler():
	"""Control MPD"""
	
	_host       = 'localhost'
	_port       = 6600
	_password   = ''
	socket      = False
	reader      = None
	status      = {'state': 'not connected'}
	stats       = {}
	index       = 0
	song        = None
	bitrate     = 0
	timer       = 0
	timera      = 0
	percent     = 0
	volume      = 0
	repeat      = False
	random      = False
	song_format = ''
	
	def __init__(self, host = '', port = 0, password = ''):
		if host != '' and port > 0:
			self.setMPDInfo(host, port, password)
	
	def reset(self, resetStatus = False):
		"""Resets properties"""
		if resetStatus:
			self.status = {'state': 'not connected'}
		self.song    = None
		self.index   = 0
		self.bitrate = 0
		self.timer   = 0
		self.timera  = 0
		self.percent = 0
	
	def setMPDInfo(self, host = None, port = None, password = None):
		"""Sets the MPD host and port"""
		if host != None: self._host = str(host)
		elif port != None: self._port = int(port)
		elif password != None: self._password = str(password)
		self.disconnect()
	
	def disconnect(self):
		"""Disconnects from the server"""
		if self.socket:
			self.socket.close()
			self.socket = False
			self.reader = False
		self.reset(True)
	
	def connect(self):
		"""Connects to the server"""
		self.disconnect()
		try:
			self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			self.socket.settimeout(5000)
			self.socket.connect((self._host, self._port))
			self.reader = self.socket.makefile('r', 4096)
			self.reader.readline()
			if self._password == '' or self.send_command("password " + self._password)[-1][:2] == "OK":
				return True
		except: pass
		self.socket = False
		return False
	
	def send_command(self, cmd):
		"""Sends a command to the server"""
		if not (self.socket and self.reader): return None
		# Handle some other commands
		if cmd == "pause": cmd += " 1"
		elif cmd == "toggle": cmd = "pause"
		elif cmd == "prev": cmd += "ious"
		# Send
		self.socket.sendall(cmd + '\n')
		# Receive the reply
		lines = []
		while True:
			s = self.reader.readline()
			lines.append(s.strip())
			if s[:2] == 'OK' or s[:3] == 'ACK': break
		# Update check
		if cmd == "update": self.update(updateStats = True)
		return lines
		
	def update(self, force = False, updateStats = False):
		"""Updates the info"""
		self.reset()
		if not self.socket:
			if force: self.connect()
			if not self.socket: return False
		# Status request
		try:
			lines = self.send_command("status")
			if lines[-1] != "OK": return False
		except:
			self.status["state"] = 'connnection lost'
			self.disconnect()
			return False
		# Parse the reply (rep)
		for line in lines:
			s = line.split(':', 1)
			if len(s) > 1:
				key = s[0].lower()
				val = s[1].strip()
				self.status[key] = val
				if key == "volume": self.volume = int(val)
				elif key == "repeat": self.repeat = int(val) > 0
				elif key == "random": self.random = int(val) > 0
				elif key == "bitrate": self.bitrate = int(val)
				elif key == "song":
					self.index = int(val)
					self.song  = self.getSongInfo(self.index)
				elif key == "time":
					t = val.split(':')
					try:
						self.timer = int(t[0])
						self.timera = int(t[1])
					except:
						self.timer = self.timera = 0
		try:
			self.percent = 100 * self.timer / self.timera
			if self.percent > 100: self.percent = 100
			elif self.percent < 0: self.percent = 0
		except:
			self.percent = 0
		# Update the stats
		if updateStats:
			try:
				lines = self.send_command("stats")
				if lines[-1] == "OK":
					for line in lines:
						s = line.split(':', 1)
						if len(s) > 1: self.stats[s[0].lower()] = s[1].strip()
			except: pass
		return True
	
	def emptySongInfo(self, file, pos = 0):
		return {'file': file, 'pos': pos, 'artist': '', 'album': '', 'title': '', 'date': '', 'genre': '', 'track': '', 'time': ''}
	
	def parseInfoLines(self, lines):
		"""Parses lines into a list of songs"""
		if lines[-1][:2] != "OK": return None
		out = []
		song = None
		for line in lines:
			s = line.split(':', 1)
			key = s[0].lower()
			try: val = s[1].strip()
			except: val = '' 
			if val == '' or key == "file":
				if song != None: out.append(song)
				if key == "file": song = self.emptySongInfo(val)
				else: break
			elif song != None:
				song[key] = val
		return out
	
	def getSongInfo(self, index):
		"""Gets the informations about a song from the playlist"""
		if not self.socket: raise Exception, 'not connected'
		lines = self.send_command("playlistinfo " + str(index))
		out = self.parseInfoLines(lines)
		if out == None: return None
		return out[0]
	
	def getSongString(self, song):
		"""Converts the song info into a string"""
		if song == None: return ""
		if self.song_format.strip() != '' and self.song_format.find('$') != -1:
			try:
				txt = Template(self.song_format).substitute(song).strip()
				if txt != '': return txt
			except: pass
		try:
			if song["artist"] and song["title"]: return song["artist"] + " - " + song["title"]
		except: pass
		return song["file"]
	
	def request_playlist(self, changeVersion = -1):
		"""Gets the playlist table"""
		try:
			if not self.socket: raise Exception, 'not connected'
			if changeVersion < 0:
				print 'Request full playlist'
				lines = self.send_command('playlistinfo')
			else:
				lines = self.send_command('plchanges ' + str(changeVersion))
				if len(lines) > 1: print 'Parse playlist changes'
			return self.parseInfoLines(lines)
		except:
			pass
		return None
	
	def request_search(self, text = "", type = "any"):
		"""Gets the playlist table"""
		try:
			if not self.socket: raise Exception, 'not connected'
			print 'Request library search'
			if text == "": lines = self.send_command("listallinfo")
			else: lines = self.send_command("search " + type + " \"" + text + "\"")
			return self.parseInfoLines(lines)
		except:
			pass
		return None
	
	def getTimeString(self, val):
		"""Converts a number of seconds to a string like '00:00'"""
		s = int(val % 60)
		m = int(val / 60)
		h = int(m / 60)
		m = int(m % 60)
		out = ""
		if h > 0: out += str(h) + ':'
		out += str(m).rjust(2, '0') + ':' + str(s).rjust(2, '0')
		return out

class MPDPlaylist():
	"""MPD playlist manager"""
	
	fullList = None # array of (song, item)
	version  = 0
	items    = None # array of [int pos, str song, str timer]
	cur      = -1
	sel      = -1
	filter   = ''
	mpd      = None
	
	def __init__(self, mpd):
		self.mpd = mpd
		self.reset()
	
	def reset(self):
		"""Resets the playlist"""
		self.fullList = self.items = None
		self.version = 0
		self.cur = self.sel = -1
		self.filter = ''
	
	def getCurSong(self):
		"""Gets the current song"""
		try:
			if self.cur < 0: return None
			return self.items[self.cur][1]
		except:
			return None
	
	def setCurSong(self):
		"""Automaticaly sets/updates the current song"""
		self.cur = -1
		if self.items == None: return
		if self.mpd.index > -1:
			i = 0
			for item in self.items:
				if int(item[0]) == self.mpd.index:
					self.cur = i
					break
				i += 1
		if self.cur < 0:
			i = 0
			ssong = self.mpd.getSongString(self.mpd.song)
			for item in self.items:
				if item[1] == ssong:
					self.cur = i
					break
				i += 1
	
	def update(self, filter = None, forceFull = False, forceFilterChange = False):
		"""Updates the current playlist"""
		if not self.mpd.socket:
			self.reset()
			return
		#Update the version
		prev_version = self.version
		self.mpd.update()
		try: self.version = int(self.mpd.status["playlist"])
		except: self.version = 0
		#Update the full playlist
		changed = forceFilterChange
		if self.fullList == None or prev_version == 0 or forceFull:
			self.fullList = self.mpd.request_playlist()
			changed = True
		else:
			list = self.mpd.request_playlist(changeVersion = prev_version)
			if list != None and len(list) > 0:
				for item in list:
					pos = int(item["pos"])
					if pos >= 0:
						while pos >= len(self.fullList): self.fullList.append(None)
						self.fullList[pos] = item
				changed = True
			#Fix the size
			try: length = int(self.mpd.status["playlistlength"])
			except: length = -1
			if length > -1 and length < len(self.fullList):
				while (length < len(self.fullList)):
					self.fullList.pop()
					changed = True
		#Update the filtered playlist
		if filter == None: filter = self.filter
		sel = -1
		if self.sel > -1:
			try: sel = int(self.items[self.sel][0])
			except: pass
		self.setFilter(filter, forceUpdate = changed)
		self.setCurSong()
		if sel > -1:
			i = 0
			while i < len(self.items):
				if self.items[i][0] == sel:
					self.sel = i
					break
				i += 1
		if self.sel == -1:
			self.sel = self.cur
		return self.fullList != None
	
	def setFilter(self, filter, forceUpdate = False):
		"""Sets a new filter and builds the filtered list"""
		if filter == None:
			filter = ''
		filter = str(filter)
		if filter == self.filter and not forceUpdate: return;
		self.filter = filter
		if self.fullList == None:
			self.items = None
			return;
		filter = filter.lower()
		self.items = []
		i = 0
		while i < len(self.fullList):
			val = self.fullList[i]
			val = [int(val["pos"]), self.mpd.getSongString(val), self.mpd.getTimeString(int(val['time']))]
			if filter == '' or str(int(val[0]) + 1).find(filter) != -1 or val[1].lower().find(filter) != -1:
				self.items.append(val)
			i += 1
		self.sel = -1

#
# Media Player Daemon
# Main class
#
class MusicPlayerDaemonScreenlet(screenlets.Screenlet):
	"""MPD Screenlet"""
	
	# Info
	__name__    = 'MPD Screenlet'
	__version__ = '1.0.2'
	__author__  = 'Krzysztof Magusiak'
	__desc__    = 'MPD client screenlet'
	
	# Variables
	mpd               = MPDControler()
	playlist          = MPDPlaylist(mpd)
	cover_engine      = None
	_key_controls     = True
	_refresh_playlist = 5
	_pls_jump         = True
	_pls_filter       = True
	_force_get_cover  = False
	
	# Timeouts
	_refresh          = 1000
	_timeout_update   = None
	_paint_interval   = 200
	_timeout_paint    = None
	_timeout_tooltip  = None
	
	# Runtime variables
	_playlist_update = 0
	_paint_time      = 0
	_tooltip_text    = ''
	_mousedown       = 0
	_mouse_pos       = [0, 0]
	_updating        = False
	_pl_line_height  = 1
	_buffer_back     = None
	_ci_theme        = None # group (all the interface controls)
	_ci_ctrl_vol     = None # volume
	_ci_ctrl_chks    = None # group of 2 buttons: repeat, random
	_ci_pbr_img      = None # group of 4 images: done, bg, left, right
	_ci_playlist     = None # group of 2 buttons: playlist, playlist_scroll
	_ci_coverart     = None # image
	_ci_txt_template = None # ciTemplate
	
	# Display
	d_show_over  = True
	d_text_font  = 'Sans 9'
	d_text_size  = 8
	d_text_color = [1, 1, 1, 1]
	
	_remaining_timer = False
	_pls_num         = True
	_pls_timer       = True
	
	# Display components
	dc_vol      = None
	dc_playlist = None
	
	def __init__(self, **keyword_args):
		"""Initialize MPD"""
		#Screenlet
		screenlets.Screenlet.__init__(self, uses_theme=True, **keyword_args)
		self.theme_name = "default"
		
		#Options
		opts = 'MPD Connection'
		self.add_options_group(opts, 'MPD Screenlet Options - connection')
		self.add_option(StringOption(opts, 'mpd._host', self.mpd._host, 'MPD Host', 'Address to connect to (ex: 127.0.0.1)'))
		self.add_option(IntOption(opts, 'mpd._port', self.mpd._port, 'MPD Port', 'Port to connect to (default: 6600)', min=0, max=64536))
		self.add_option(StringOption(opts, 'mpd._password', self.mpd._password, 'MPD Password', 'Password', password = True))
		self.add_option(IntOption(opts, '_refresh', self._refresh, 'Refresh rate', 'MPD information update rate (in ms)', min=200, max=60000, increment=100))
		self.add_option(IntOption(opts, '_refresh_playlist', self._refresh_playlist, 'Playlist update', 'Update playlist every # updates', min=1, max=60))
		opts = 'MPD Display'
		self.add_options_group(opts, 'MPD Screenlet Options - display & colors')
		self.add_option(StringOption(opts, 'mpd.song_format', self.mpd.song_format, 'Song format', 'The format of the displayed song. The parts like "${name}" will be replaced, the name is one of the following: artist, album, date, genre, title, track'))
		self.add_option(IntOption(opts, '_paint_interval', self._paint_interval, 'Redraw check rate', 'How often check if the interface has to be redrawn (in ms)', min=20, max=60000, increment=20))
		self.add_option(BoolOption(opts, '_remaining_timer', self._remaining_timer, 'Remaining timer', 'Whether the remaining timer is the default'))
		self.add_option(BoolOption(opts, 'd_show_over', self.d_show_over, 'Display over images', 'Display mouse-over images'))
		self.add_option(FontOption(opts, 'd_text_font', self.d_text_font, 'Font face', 'Default font face'))
		self.add_option(IntOption(opts, 'd_text_size', self.d_text_size, 'Font size', 'Default font size', min=5, max=48))
		self.add_option(ColorOption(opts, 'd_text_color', self.d_text_color, 'Font color', 'Default font color'))
		self.add_option(BoolOption(opts, '_pls_num', self._pls_num, 'Playlist position numbers', 'Display the position of the song in the playlist'))
		self.add_option(BoolOption(opts, '_pls_timer', self._pls_timer, 'Playlist timers', 'Display the timer for each song in the playlist'))
		opts = 'MPD Other'
		self.add_options_group(opts, 'MPD Screenlet Options - other options')
		self.add_option(BoolOption(opts, '_key_controls', self._key_controls, 'Control with keys', 'Allow to control the player using keys'))
		self.add_option(BoolOption(opts, '_pls_jump', self._pls_jump, 'Playlist jump', 'Jump in the playlist to the entry that matches the typed text ([Control with keys] must be checked)'))
		self.add_option(BoolOption(opts, '_pls_filter', self._pls_filter, 'Filter playlist', 'Filter the playlist instead of jumping ([Playlist jump] must be checked)'))
		self.add_option(BoolOption(opts, '_force_get_cover', self._force_get_cover, 'Force get artwork', 'Always try to get the artwork, even if the album is not specified'))
	
	def __setattr__(self, name, value):
		"""Sets an attribute"""
		screenlets.Screenlet.__setattr__(self, name, value)
		if name == '_refresh':
			if self._timeout_update != None:
				gobject.source_remove(self._timeout_update)
			self._timeout_update = gobject.timeout_add(value, self.update)
			print 'MPD refresh rate set to ' + str(value) + 'ms'
		elif name == '_paint_interval':
			if self._timeout_paint != None:
				gobject.source_remove(self._timeout_paint)
			self._timeout_paint = gobject.timeout_add(value, self.update_check)
			print 'Paint check rate set to ' + str(value) + 'ms'
		elif name == 'mpd._host':
			self.mpd.setMPDInfo(host = value)
			print "MPD Password changed"
		elif name == 'mpd._port':
			self.mpd.setMPDInfo(port = value)
			print "MPD Port changed"
		elif name == 'mpd._password':
			self.mpd.setMPDInfo(password = value)
			print "MPD Password changed"
		elif name == "mpd.song_format":
			self.mpd.song_format = value
			self.playlist.update(forceFilterChange = True)
			if self._ci_theme: self._ci_theme._toPaint = True
		elif name[:2] == "d_":
			self.loadControls()
		elif name == "_force_get_cover":
			self.update_coverart()
		elif name == 'resize_on_scroll': #deactivate this option
			if self.resize_on_scroll: self.resize_on_scroll = False
	
	def on_init(self):
		print "MPD Screenlet has been initialized."
		
		#Menu
		self.add_default_menuitems(DefaultMenuItem.XML)
		self.add_default_menuitems(DefaultMenuItem.SIZE | DefaultMenuItem.THEMES | DefaultMenuItem.WINDOW_MENU | DefaultMenuItem.PROPERTIES | DefaultMenuItem.QUIT)
		
		#MPD
		self.mpd.update(force = True, updateStats = True)
		
		#Initialize controls
		self.loadControls(forceLoad = True)
		self.playlist.sel = self.playlist.cur
		
		#Timeout
		self.__setattr__("_refresh", self._refresh)
		self.__setattr__("_paint_interval", self._paint_interval)
		
		#Update
		self.update_shape()
	
	def loadControls(self, forceLoad = False):
		"""Loads the screenlet interface"""
		if not self.theme or (not forceLoad and self._ci_theme == None):
			print 'Interface not loaded...'
			self._ci_theme = None
			return
		print 'Loading the screenlet interface: ' + str(self.theme_name)
		try:
			dom = xml.dom.minidom.parse(os.path.join(self.theme.path, 'theme_display.xml'))
			display = dom.getElementsByTagName("display")[0]
		except:
			print 'Error: Invalid theme display (xml file)'
			return
		self.width = int(display.getAttribute('width'))
		self.height = int(display.getAttribute('height'))
		#Initialize _ci_*
		self._ci_theme        = ciGroup()
		self._ci_ctrl_vol     = None
		self._ci_ctrl_chks    = ciGroup(elements = 2)
		self._ci_pbr_img      = None
		self._ci_playlist     = ciGroup(elements = 2)
		self._ci_coverart     = None
		self._ci_txt_template = ciTemplate()
		#Initialize other properties
		self.dc_vol      = {'bg': None, 'used': [0, 0, 1, 1]}
		self.dc_playlist = {'cur': [0, 0, 0, 1], 'sel': [0, 0, 1, 1], 'sel_bg': [0, 0, 0, 0], 'text': None, \
			'scroll': {'color' : [0.2, 0.2, 0.2, 1], 'rounded': 0, 'border': {'width': 0, 'color': [0, 0, 0, 0]}}}
		#Load
		self.loadControlsNode(self._ci_theme, display)
		#Background buffer
		self._buffer_back = gtk.gdk.Pixmap(self.window.window, int(self.width * self.scale), int(self.height * self.scale), -1)
		bctx = self._buffer_back.cairo_create()
		self.clear_cairo_context(bctx)
		bctx.scale(self.scale, self.scale)
		self._ci_theme.paint(self, bctx, 2)
		#Update
		self.hide_filter()
		self.update(plForceUpdate = True, updateCover = True)
		gc.collect()
	
	def loadControlsNode(self, ci, node):
		"""Loads a node from a theme display file"""
		if node.nodeType == 1:
			for n in node.childNodes:
				if n.nodeType == 1:
					type = n.nodeName
					obj  = None
					grp  = None
					if type == 'execute':
						try:
							ex = n.childNodes[0].nodeValue.strip()
							if ex[:5] != 'self.': ex = 'self.' + ex
							if ex.find("=") != -1 and ex.find("\n") == -1: exec ex
						except: pass
					elif type == 'group':
						grp = obj = ciGroup()
					elif type == 'text':
						obj = ciText(''.join(map(xml.dom.minidom.Node.toxml, n.childNodes)).strip(), template = self._ci_txt_template)
						try: obj.width = int(n.getAttribute('width'))
						except:
							try: obj.width = self.width - int(n.getAttribute('x'))
							except ValueError: obj.width = self.width
						try: exec 'obj.color = ' + n.getAttribute('color')
						except: obj.color = self.d_text_color
						obj.font = n.getAttribute('font')
						if obj.font == '': obj.font = self.d_text_font
						try: obj.size = int(n.getAttribute('size'))
						except: obj.size = self.d_text_size
						align = n.getAttribute('align')
						if align == 'center': obj.align = pango.ALIGN_CENTER
						elif align == 'right': obj.align = pango.ALIGN_RIGHT
						singleline = n.getAttribute('singleline')
						if len(singleline) > 0: obj.line = bool(int(singleline))
					elif type == 'image' or type == 'button':
						obj = ciButton(n.getAttribute('src'))
						if self.d_show_over: obj.srcOver = n.getAttribute('src_over')
						ratio = n.getAttribute('preserve_scale_ratio')
						if len(ratio) > 0: obj.pre_aspect = bool(int(ratio))
						try: exec 'obj.eventClick = ' + n.getAttribute('on_click')
						except: obj.eventClick = None
						action = n.getAttribute('action')
						if action: obj.action = action
					if type == 'group' or type == 'image' or type == 'button':
						try: obj.width = int(n.getAttribute('width'))
						except ValueError: obj.width = -1
						try: obj.height = int(n.getAttribute('height'))
						except ValueError: obj.height = -1
					if obj != None:
						ci.add_ci(obj)
						try: obj.x = int(n.getAttribute('x'))
						except ValueError: obj.x = 0
						try: obj.y = int(n.getAttribute('y'))
						except ValueError: obj.y = 0
						try: exec 'obj.eventPaint = ' + n.getAttribute('on_paint')
						except: obj.eventPaint = None
						if n.getAttribute('background'): obj._back = True
						self.loadControlsNodeCheck(obj, n.getAttribute('id'))
						if grp: self.loadControlsNode(grp, n)
	
	def loadControlsNodeCheck(self, obj, name):
		"""Checks if the object has to be saved for other purposes"""
		if obj == None or name == None or name == '':
			return
		elif name == "progress":
			self._ci_pbr_img = obj
			if obj.width < 1: obj.width = self.width - 2 * obj.x
		elif name[:9] == "progress_":
			if self._ci_pbr_img.height > 0 and obj.height < 1: obj.height = self._ci_pbr_img.height
			if name == "progress_right": obj.x = self._ci_pbr_img.width
		elif name == "volume": self._ci_ctrl_vol = obj
		elif name == "repeat": self._ci_ctrl_chks[0] = obj
		elif name == "random": self._ci_ctrl_chks[1] = obj
		elif name == "playlist": self._ci_playlist[0] = obj
		elif name == "playlist_scroll": self._ci_playlist[1] = obj
		elif name == "coverart": self._ci_coverart = obj

	def update(self, plForceUpdate = False, plUpdateSelect = -2, updateStats = False, updateCover = False):
		"""Updates the screenlet interface"""
		if self._updating or self._ci_theme == None:
			return False
		self._updaing = True
		#MPD
		prev = self.mpd.song
		self.mpd.update(plForceUpdate, updateStats = updateStats)
		song_changed = self.mpd.song != prev
		#Status (update the template)
		if self._ci_txt_template:
			self._ci_txt_template.setValue('song', self.mpd.getSongString(self.mpd.song))
			song = self.mpd.song
			if song == None: song = self.mpd.emptySongInfo('')
			for item in ['album', 'artist', 'date', 'genre', 'title', 'track']:
				self._ci_txt_template.setValue('song_' + item, song[item])
			self._ci_txt_template.setValue('status', self.mpd.status['state'])
			self._ci_txt_template.setValue('bitrate', self.mpd.bitrate)
			self._ci_txt_template.setValue('position', self.mpd.index + 1)
			timer = self.mpd.getTimeString(self.mpd.timer)
			self._ci_txt_template.setValue('timer_cur', timer)
			rtimer = '-' + self.mpd.getTimeString(self.mpd.timera - self.mpd.timer)
			self._ci_txt_template.setValue('timer_remain', rtimer)
			atimer = self.mpd.getTimeString(self.mpd.timera)
			self._ci_txt_template.setValue('timer_all', atimer)
			if self._remaining_timer: txt = rtimer
			else: txt = timer
			self._ci_txt_template.setValue('timer', txt)
			if self.mpd.timera > 0: txt = txt + '/' + atimer
			else: txt = ''
			self._ci_txt_template.setValue('timer_full', txt)
			self._ci_txt_template.setValue('timer_percent', self.mpd.percent)
			self._ci_txt_template.setValue('volume', self.mpd.volume)
			if self.mpd.repeat: txt = 'ON'
			else: txt = 'OFF'
			self._ci_txt_template.setValue('repeat', txt)
			if self.mpd.random: txt = 'ON'
			else: txt = 'OFF'
			self._ci_txt_template.setValue('random', txt)
			try: self._ci_txt_template.setValue('xfade', self.mpd.status['xfade'])
			except: pass
			for stat in ['artists', 'albums', 'songs', 'uptime', 'playtime']:
				try: self._ci_txt_template.setValue('stats_' + stat, self.mpd.stats[stat])
				except: pass
		#Progress
		if self._ci_pbr_img != None:
			self._ci_pbr_img[1].x = self._ci_pbr_img[0].width = float(self._ci_pbr_img.width * self.mpd.percent) / 100
			self._ci_pbr_img[1].width = self._ci_pbr_img.width - self._ci_pbr_img[0].width
		#Checkboxes
		i = 0
		while i < 2:
			if self._ci_ctrl_chks[i] != None:
				if (i == 0 and self.mpd.repeat) or (i == 1 and self.mpd.random): val = 'on'
				else: val = 'off'
				self._ci_ctrl_chks[i].src = self._ci_ctrl_chks[i].src[:self._ci_ctrl_chks[i].src.rfind('_') + 1] + val
			i += 1
		#Playlist
		if self.playlist != None and self._ci_playlist[0] != None:
			if song_changed or plForceUpdate: self._playlist_update = 0
			if self._playlist_update == 0:
				increment = self.playlist.update()
			else:
				increment = True
				self.playlist.setCurSong()
			if increment: self._playlist_update = (self._playlist_update + 1) % self._refresh_playlist
			if plUpdateSelect > -2:
				self.playlist.sel = plUpdateSelect
			elif (song_changed or plForceUpdate) and self.playlist.cur > -1:
				self.playlist.sel = self.playlist.cur
		elif self._ci_playlist[0] == None:
			self.playlist.reset()
		#Coverart
		if song_changed or updateCover: self.update_coverart()
		#Redraw
		self._ci_theme._toPaint = True
		self._updating = False
		return True
	
	def update_coverart(self):
		"""Updates the coverart"""
		try: COVER_FILE = screenlets.DIR_TMP
		except: COVER_FILE = '/tmp/'
		COVER_FILE += 'screenlet_' + self.id + '_cover.jpg'
		try: artist = self.mpd.song["artist"]
		except: artist = ''
		try: album = self.mpd.song["album"]
		except: album = ''
		if self.cover_engine:
			if self.cover_engine.artist.lower() == artist.lower() and self.cover_engine.album.lower() == album.lower():
				self.update_coverart_cb(COVER_FILE)
				return
			else:
				self.cover_engine.AlbumCover = ''
				self.cover_engine.callback_fn = empty_function
				self.cover_engine = None
		# Some cleanup
		if os.path.isfile(COVER_FILE): os.remove(COVER_FILE)
		self.update_coverart_cb(False)
		if self._ci_coverart == None or (album == '' and artist == '') or \
				(not self._force_get_cover and (album == '' or artist == '')):
			return
		print 'Request new coverart...'
		self.cover_engine = CoverSearch.CoverSearch()
		self.cover_engine.AlbumCover = COVER_FILE
		self.cover_engine.initData(artist, album, self.update_coverart_cb)
		self.cover_engine.start()
	
	def update_coverart_cb(self, path):
		"""Coverart update callback"""
		if self._ci_coverart == None: return
		print 'Setting cover path: ' + str(path)
		if path: path = str(path)
		else: path = ''
		self._ci_coverart.src = path
		self._ci_theme._toPaint = True
	
	def update_check(self):
		"""Checks if the interface has to be redrawn"""
		if self._ci_theme and self._ci_theme._toPaint:
			self.redraw_canvas()
		return True

	def on_draw(self, ctx):
		"""Draws the interface"""
		if self._ci_theme != None:
			ctx.set_operator(cairo.OPERATOR_OVER)
			ctx.save()
			if self._buffer_back:
				ctx.set_source_pixmap(self._buffer_back, 0, 0)
				ctx.paint()
			ctx.scale(self.scale, self.scale)
			self._ci_theme.paint(self, ctx)
			ctx.fill()
			ctx.restore()
	 
	def on_draw_shape(self, ctx):
		self.on_draw(ctx)
	
	def draw_playlist(self, slet, ctx):
		"""Draws the playlist items"""
		if self.playlist.items == None or len(self.playlist.items) == 0 or self._ci_playlist[0] == None:
			return
		width  = self._ci_playlist[0].width
		height = self._ci_playlist[0].height
		size   = len(self.playlist.items)
		font   = self.d_text_font.rstrip(' 1234567890')
		bNum   = bool(self._pls_num)
		bTimer = bool(self._pls_timer)
		line_size = get_text_size(slet, ctx, "ABC", font, self.d_text_size, isHTML = True)
		self._pl_line_height = line_height = line_size[3][1]
		line_bg_height = line_size[0][1]
		del line_size
		ctx.save()
		if self.dc_playlist["text"]: color = self.dc_playlist["text"]
		else: color = self.d_text_color
		ctx.set_source_rgba(color[0], color[1], color[2], color[3])
		estim_item = int(height / line_height)
		sel = self.playlist.sel
		i = sel - estim_item / 2 + 1
		if i + estim_item > size: i = size - estim_item
		if i < 0: i = 0
		y = 0
		while i < size and y + line_height < height:
			#Get the text
			text = htmlentities(self.playlist.items[i][1])
			if bNum: text = htmlentities(str(self.playlist.items[i][0] + 1) + '. ') + text
			timer = ''
			if bTimer: timer = htmlentities(self.playlist.items[i][2])
			timer_width = get_text_size(slet, ctx, timer, font, self.d_text_size, isHTML = True)[1][0]
			if timer_width: timer_width += 5
			text = fix_text_render_on_line(slet, ctx, text, font, self.d_text_size, width - timer_width)
			#Paint
			if i == sel:
				color = self.dc_playlist['sel_bg']
				if color[3] > 0:
					ctx.save()
					ctx.set_source_rgba(color[0], color[1], color[2], color[3])
					slet.draw_rectangle(ctx, 0, y + 1, width, line_height)
					ctx.restore()
				ctx.save()
				color = self.dc_playlist['sel']
				ctx.set_source_rgba(color[0], color[1], color[2], color[3])
			if i == self.playlist.cur:
				ctx.save()
				color = self.dc_playlist['cur']
				ctx.set_source_rgba(color[0], color[1], color[2], color[3])
			slet.draw_text(ctx, text, 0, y, font, self.d_text_size, width, pango.ALIGN_LEFT)
			slet.draw_text(ctx, timer, 0, y, font, self.d_text_size, width, pango.ALIGN_RIGHT)
			if i == sel: ctx.restore()
			if i == self.playlist.cur: ctx.restore()
			i += 1
			y += line_height
		ctx.restore()
	
	def draw_playlist_scrollbar(self, slet, ctx):
		"""Draws the playlist scrollbar"""
		if self.playlist.items == None or len(self.playlist.items) < 2 or self._ci_playlist[1] == None:
			return
		width  = self._ci_playlist[1].width
		height = self._ci_playlist[1].height
		try: percent = float(self.playlist.sel) / (len(self.playlist.items) - 1)
		except: percent = -1
		if percent > 1: percent = 1
		elif percent < 0: return
		indic = [0, 0, width, height, 0] # [x, y, width, height, rounded]
		if width > height: # horizontal
			indic[2] = int(indic[2] / 10)
			indic[0] = int((width - indic[2]) * percent)
		else: # vertical
			indic[3] = int(indic[3] / 10)
			indic[1] = int((height - indic[3]) * percent)
		if self.dc_playlist["scroll"]["rounded"]:
			indic[4] = int(min(indic[2], indic[3]) / self.dc_playlist["scroll"]["rounded"])
		ctx.save()
		color = self.dc_playlist["scroll"]["color"]
		ctx.set_source_rgba(color[0], color[1], color[2], color[3])
		#slet.draw_rounded_rectangle(ctx, indic[0], indic[1], indic[4], indic[2], indic[3])
		slet.draw_rectangle_advanced(ctx, indic[0], indic[1], indic[2], indic[3], \
			rounded_angles = (indic[4], indic[4], indic[4], indic[4]), \
			border_size = self.dc_playlist["scroll"]["border"]["width"], \
			border_color = self.dc_playlist["scroll"]["border"]["color"])
		ctx.restore()
	
	def draw_volume(self, slet, ctx):
		"""Draws the volume bars"""
		width  = self._ci_ctrl_vol.width
		height = self._ci_ctrl_vol.height
		bar_width  = float(width) / 30
		bar_height = float(height) / 10
		ctx.save()
		color = self.dc_vol['used']
		ctx.set_source_rgba(color[0], color[1], color[2], color[3])
		i = 0
		while i < 10:
			i += 1
			if (self.mpd.volume / 10) < i:
				color = self.dc_vol['bg']
				if color == None: color = self.d_text_color
				ctx.set_source_rgba(color[0], color[1], color[2], color[3])
			slet.draw_rectangle(ctx, (i - 1) * bar_width * 3, height - i * bar_height, bar_width * 2, i * bar_height)
		ctx.restore()
		
	def on_mouse_down(self, event):
		"""A click was performed"""
		self._mousedown = event.button
		self._mouse_pos = [(event.x_root - self.x) / self.scale, (event.y_root - self.y) / self.scale]
		if event.button == 1:
			if self._ci_theme:
				if self._ci_theme.mouse_click(self._mouse_pos[0], self._mouse_pos[1], self._mousedown):
					return True
			self.is_dragged = True
		elif event.button == 3:
			self.menu.popup(None, None, None, event.button, event.time)
		return False
	
	def on_mouse_up(self, event):
		"""The mouse is up"""
		self._mousedown = 0
		return True
	
	def on_mouse_move(self, event):
		"""The mouse is moving"""
		self._mouse_pos = [(event.x_root - self.x) / self.scale, (event.y_root - self.y) / self.scale]
		if self._ci_theme and self.d_show_over and not self._updating:
			self._ci_theme.isOver(self._mouse_pos[0], self._mouse_pos[1])
		return True
	
	def on_mouse_leave(self, event):
		"""The mouse moved out of the screenlet"""
		self._mousedown = 0
		return self.on_mouse_move(event)
	
	def on_scroll_up(self):
		"""Occurs when the mouse wheel is scrolled up"""
		self.playlist_select_change(-1)
	
	def on_scroll_down(self):
		"""Occurs when the mouse wheel is scrolled down"""
		self.playlist_select_change(1)
	
	def on_key_down(self, keyCode, keyValue, event = None):
		"""A key was pressed"""
		if not self._key_controls:
			return False
		if self.playlist != None and self._ci_playlist[0] != None:
			if keyCode == 32 and self.tooltip == None: #Space
				return self.playlist_select_current()
			elif keyCode == 65293: #Enter
				play = self.playlist.items[self.playlist.sel][0]
				if play >= 0:
					self.mpd.send_command('play ' + str(play))
					self.update()
					return True
			elif keyCode == 65362 or keyCode == 65364 or keyCode == 65365 or keyCode == 65366 or keyCode == 65360 or keyCode == 65367:
				#(Pg)Up - 65362 (65365) or (Pg)Down - 65364 (65366) or Home - 65360 or End - 65367
				if keyCode == 65362 or keyCode == 65365 or keyCode == 65360: dir = -1
				else: dir = 1
				if keyCode == 65365 or keyCode == 65366: dir *= 5
				elif keyCode == 65360 or keyCode == 65367: dir *= len(self.playlist.items)
				move = event and event.state == gtk.gdk.CONTROL_MASK #+Ctrl
				if self.playlist_select_change(dir, move): return True
			elif keyCode == 65535: #Delete
				if self.playlist_delete_selected(): return True
			elif keyCode == 65307 and self._timeout_tooltip: #Esc
				gobject.source_remove(self._timeout_tooltip)
				if self._pls_filter: self.hide_filter()
				else: self.hide_tooltip()
				return True
			elif keyCode == 65288 and self.tooltip != None: #Backspace
				self._tooltip_text = self._tooltip_text[:-1]
				if self._tooltip_text == '':
					self.on_key_down(65307, keyValue, '')
				elif self._pls_filter:
					self.playlist.update(self._tooltip_text)
					self._ci_theme._toPaint = True
				if self.tooltip:
					self.tooltip.text = htmlentities(self._tooltip_text)
				return True
			elif self._pls_jump and re.match('[\w,./? -_=+]', keyValue) != None: #Jump (filter)
				self._tooltip_text += keyValue
				self.show_tooltip(htmlentities(self._tooltip_text), self.x, self.y + self.height * self.scale)
				if self._timeout_tooltip:
					gobject.source_remove(self._timeout_tooltip)
				if self._pls_filter:
					# Filter
					self._timeout_tooltip = gobject.timeout_add(25000, self.hide_filter)
					self.playlist.update(self._tooltip_text)
					self._ci_theme._toPaint = True
				else:
					# Jump
					self._timeout_tooltip = gobject.timeout_add(2500, self.hide_tooltip)
					text = self._tooltip_text.lower()
					sel  = self.playlist.sel
					size = len(self.playlist.items)
					while sel < size:
						if self.playlist.items[sel][1][:len(text)].lower() == text or str(self.playlist.items[sel][0] + 1)[:len(text)] == text:
							if self.playlist.sel != sel:
								self.playlist.sel = sel
								self._ci_theme._toPaint = True
							break
						sel += 1
				return True
		if keyCode == 65361: #Left
			time = self.mpd.timer - 10
			if time > 0:
				self.mpd.send_command('seek ' + str(self.mpd.index) + ' ' + str(time))
				return True
		elif keyCode == 65363: #Right
			time = self.mpd.timer + 10
			if time < self.mpd.timera:
				self.mpd.send_command('seek ' + str(self.mpd.index) + ' ' + str(time))
				return True
		#print 'Key pressed: ' + str(keyCode) + ' ' + keyValue
		return False
	
	def hide_tooltip(self):
		self._tooltip_text = ''
		screenlets.Screenlet.hide_tooltip(self)
		
	def hide_filter(self):
		self.hide_tooltip()
		if self.playlist.filter:
			self.playlist.update('')
			self._ci_theme._toPaint = True
	
	def playlist_select_current(self):
		"""Selects the current song in the playlist"""
		self.playlist.sel = self.playlist.cur
		self._ci_theme._toPaint = True
		return True
	
	def playlist_move_current(self, offset):
		"""Moves the selected song in the playlist"""
		offset = int(offset)
		if offset and self.playlist.sel > -1:
			try:
				if -offset > self.playlist.sel:
					offset = -self.playlist.sel
				elif len(self.playlist.items) <= self.playlist.sel + offset:
					offset = len(self.playlist.items) - self.playlist.sel - 1
				pos1 = int(self.playlist.items[self.playlist.sel][0])
				pos2 = int(self.playlist.items[self.playlist.sel + offset][0])
			except:
				print 'Cannot move the selected item!'
				pos1 = pos2 = 0
			if pos1 != pos2:
				self.mpd.send_command('move ' + str(pos1) + ' ' + str(pos2))
				self.update(plForceUpdate = True, plUpdateSelect = self.playlist.sel + offset)
				return True
		return False
	
	def playlist_select_change(self, dir, move = False):
		"""Changes the selection of the playlist"""
		if self.playlist != None and self._ci_playlist[0] != None:
			if move:
				return self.playlist_move_current(dir)
			else:
				sel = self.playlist.sel + dir
				if sel < 0: sel = 0
				elif sel > len(self.playlist.items) - 1: sel = len(self.playlist.items) - 1
				self.playlist.sel = sel
				self._ci_theme._toPaint = True
				return True
		return False
	
	def playlist_add_dialog(self):
		"""Shows the add dialog"""
		MPDAddFrame(self).setVisible(True)
	
	def playlist_delete_selected(self):
		"""Deletes the currently selected item from the playlist"""
		try: sel = self.playlist.items[self.playlist.sel][0]
		except: sel = 0
		if sel > 0:
			self.mpd.send_command('delete ' + str(sel))
			sel = self.playlist.sel
			if sel >= len(self.playlist.items) - 1:
				sel = len(self.playlist.items) - 2
			self.update(plForceUpdate = True, plUpdateSelect = sel)
			return True
		return False
	
	def playlist_sort(self):
		"""Sorts the playlist"""
		list = self.mpd.request_playlist()
		if list and len(list) > 1:
			items = [self.mpd.getSongString(list[0]).lower()]
			done = True
			i = 1
			while i < len(list):
				items.append(self.mpd.getSongString(list[i]).lower())
				if items[i - 1] > items[i]: done = False
				i += 1
			if done: return True
			# Sort
			def playlist_swap(items, i, j):
				tmp = items[i]
				items[i] = items[j]
				items[j] = tmp
				return '\nswap ' + str(i) + ' ' + str(j)
			def playlist_quicksort(items, lo, hi):
				if lo >= hi: return ''
				elif lo + 1 == hi:
					if items[lo] > items[hi]: return playlist_swap(items, lo, hi)
					return ''
				cmd = ''
				pi = int((lo + hi) / 2)
				# sort: items[lo] <= items[hi] <= items[pi]
				if items[lo] > items[pi]: cmd += playlist_swap(items, lo, pi)
				if items[lo] > items[hi]: cmd += playlist_swap(items, lo, hi)
				if items[hi] > items[pi]: cmd += playlist_swap(items, hi, pi)
				i = lo
				j = hi - 1
				pivot = items[hi]
				done = False
				while True:
					while items[i] <= pivot:
						i += 1
						if i == hi: done = True; break
					while items[j] >= pivot:
						j -= 1
						if j < lo: done = True; break
					if done or i > j: break
					cmd += playlist_swap(items, i, j)
				if hi > i: cmd += playlist_swap(items, hi, i)
				cmd += playlist_quicksort(items, lo, j)
				cmd += playlist_quicksort(items, i + 1, hi)
				return cmd
			cmd = 'command_list_begin' + playlist_quicksort(items, 0, len(items) - 1) + '\ncommand_list_end'
			self.mpd.send_command(cmd)
			self.update(plForceUpdate = True)
			return True
		return False
	
	def playlist_shuffle(self):
		"""Shuffle the playlist"""
		self.mpd.send_command('shuffle')
		self.update(plForceUpdate = True)
		return True
	
	def on_menuitem_select (self, id):
		"""Handles menu items"""
		if id[:7] == "player_":
			for l in ("play", "pause", "toggle", "stop", "prev", "next"):
				if id[7:] == l:
					self.mpd.send_command(l)
					self.update()
					break
		elif id[:9] == "playlist_":
			ev = ciEvent()
			ev.button = 1
			ev.action = id[9:]
			self.event_playlist_click(ev)
		else:
			ev = ciEvent()
			ev.button = 1
			ev.action = id
			self.event_button_click(ev)
	
	def event_pbr_click(self, ev):
		"""User clicked on the progress bar"""
		if ev.button == 1:
			width = self._ci_pbr_img.width
			pos = ev.x
			time = self.mpd.timera
			if time > 0 and width > 0 and pos >= 0:
				self.mpd.send_command("seek " + str(self.mpd.index) + ' ' + str(int(float(time) * pos / width)))
				self.update()
	
	def event_volume_click(self, ev):
		"""User clicked on the volume bar"""
		if ev.button == 1:
			vol = int(float(ev.x - ev.source.x) / (ev.source.width - 2) * 100)
			if vol > 100: vol = 100
			elif vol < 0: vol = 0
			if vol != self.mpd.volume:
				self.mpd.send_command(ev.action + ' ' + str(vol))
				self.update()
	
	def event_player_click(self, ev):
		"""User clicked on a player button"""
		if ev.button == 1:
			self.mpd.send_command(ev.action)
			self.update()
		
	def event_button_click(self, ev):
		"""User clicked on a button"""
		if ev.button == 1:
			if ev.action == "toggle_remaining_timer":
				self._remaining_timer = not self._remaining_timer
			elif ev.action == "random" or ev.action == "repeat":
				if ev.action == "repeat": txt = not self.mpd.repeat
				else: txt = not self.mpd.random
				if txt: txt = "1"
				else: txt = "0"
				self.mpd.send_command(ev.action + ' ' + txt)
				self.update()
			elif ev.action[:10] == "set_theme ":
				self.theme_name = ev.action[10:].strip()
			elif ev.action == "updatedb":
				self.mpd.send_command("update")
			elif ev.action == "reconnect":
				self.mpd.connect()
				self.update(updateStats = True)
	
	_event_playlist_click_time = 0
	def event_playlist_click(self, ev):
		"""User clicked on the playlist"""
		if ev.button == 1:
			if ev.action == 'add':
				self.playlist_add_dialog()
			elif ev.action == 'del':
				self.playlist_delete_selected()
			elif ev.action == 'clear':
				self.mpd.send_command(ev.action)
				self.update(plForceUpdate = True)
			elif ev.action == 'playall':
				self.mpd.send_command('command_list_begin\nclear\nadd /\nplay\ncommand_list_end')
				self.update(plForceUpdate = True)
			elif ev.action == 'selectcur':
				self.playlist_select_current()
			elif ev.action == 'sort':
				self.playlist_sort()
			elif ev.action == 'shuffle':
				self.playlist_shuffle()
			elif self.playlist.sel > -1 and ev.action[:5] == "move ":
				self.playlist_move_current(ev.action[5:])
			elif ev.action == 'scroller':
				plsize = len(self.playlist.items)
				if plsize < 1: self.playlist.sel = -1
				elif plsize == 1: self.playlist.sel = 0
				else:
					if ev.source.width > ev.source.height:
						percent = float(ev.x - ev.source.x)
						size = ev.source.width
					else:
						percent = float(ev.y - ev.source.y)
						size = ev.source.height
					scroller_size = size / 10
					size -= scroller_size
					percent -= scroller_size / 2
					if percent < 0: percent = 0
					elif percent > size: percent = 1
					else: percent /= size
					self.playlist.sel = int(round(percent * (plsize - 1)))
					self._ci_theme._toPaint = True
			elif ev.action == 'playlist' and self.playlist.items != None:
				if ev.time - self._event_playlist_click_time < max(800, self._paint_interval):
					self.mpd.send_command('play ' + str(self.playlist.items[self.playlist.sel][0]))
					self.update()
				else:
					element     = int(float(ev.y - ev.source.y) / self._pl_line_height)
					size        = len(self.playlist.items)
					estim_item  = int(ev.source.height / self._pl_line_height)
					sel         = self.playlist.sel + 1
					if size >= estim_item / 2: sel -= int((estim_item + 1) / 2)
					if sel + estim_item > size: sel = size - estim_item
					if sel < 0: sel = 0
					sel += element
					if sel > size - 1: sel = size - 1
					if self.playlist.sel != sel:
						self.playlist.sel = sel
						self._ci_theme._toPaint = True
				self._event_playlist_click_time = ev.time
			else:
				return False
			return True
		return False
	
	def on_scale(self):                                        
		"""The window has been scaled"""
		self.loadControls()
	
	def on_load_theme(self):
		"""A theme has been loaded"""
		self.loadControls()

if __name__ == "__main__":
	import screenlets.session
	screenlets.session.create_session(MusicPlayerDaemonScreenlet)
