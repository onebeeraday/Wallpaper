********************************************************************************
* MusicPlayerDaemon (MPD) Screenlet v1.0 - README                              *
* by Krzysztof Magusiak <chrmag@poczta.onet.pl>                                *
********************************************************************************

   I. Installing and configuring MPD
  II. MPD Screenlet options
 III. Shortcuts
  IV. Theme developing

--------------------------------------------------------------------------------

   I. Installing and configuring MPD

 - Installing:
  sudo apt-get install mpd
You may also want to install mpc which is a console client.

 - Starting & Stoping:
  sudo /etc/init.d/mpd {command}
  Where {command} is: start, stop or restart

 - Configuring:
Just edit the file /etc/mpd.conf and then restart MPD.
You will have to edit the path music_directory.
MPD runs by default on port 6600.


  II. MPD Screenlet options

 - Screenlet options:
Here you can set the position of the screenlet, its transparency, and some other
window options.
The option 'Resize on mouse scroll' cannot be activated in this program beacause
the mouse scroll is used inside the playlist.

 - MPD Connection:
You can change the host, the port and the password used by this client.
Also, you can set the rate of queries sent to the server.

 - MPD Display & Others:
How the screenlet is rendered.


 III. Shortcuts

The option 'Control with keys' must be active.
 - General:
   - left arrow: playback seek -10s
   - right arrow: playback seek +10s
 - Playlist:
   - space: select the current song
   - enter: play the selected song
   - up/down arrow & PgUp/PgDn & home/end:
     goes back/foward in the playlist
	   - arrow: by 1 position
	   - PgUp/PgDn: by 5 positions
	   - home/end: begin/end of the list)
	 [+Ctrl: moves the current song to the selected position]
   - delete: removes the selected song from the playlist
   - other text: starts the jump or filter function
   - escape: stops the jump of filter function


  IV. Theme developing

See readme-theme.txt