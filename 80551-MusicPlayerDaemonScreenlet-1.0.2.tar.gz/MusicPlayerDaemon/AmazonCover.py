#! /usr/bin/env python

# This file is a copy of screenlets plugins: CoverSearch and AmazonCoverArtSearch 
# modified by Krzysztof Magusiak <chrmag@poczta.onet.pl>

# ChangeLog (2008-08-25):
#  - support Amazon Webservice Version 4

from screenlets import Plugins

# ------------------------------------------------------------------------------

# This application is released under the GNU General Public License 
# v3 (or, at your option, any later version). You can find the full 
# text of the license under http://www.gnu.org/licenses/gpl.txt. 
# By using, editing and/or distributing this software you agree to 
# the terms and conditions of this license. 
# Thank you for using free software!

Loader = Plugins.importAPI('Loader') #from Loader import Loader
import os
import threading
import time

class CoverSearch(threading.Thread):
	loader = None
	Result = False
	artist = ""
	album = ""
	callback_fn = False

	AlbumCover = "/tmp/amazon-cover-album.jpg"

	def __init__(self):
		self.loader = Loader.Loader()
		self.engine = AmazonCoverArtSearch(self.loader)
		self.Result = False
		threading.Thread.__init__(self)

	def initData(self, artist, album, fn):
		self.artist = artist
		self.album = album
		self.callback_fn = fn

	def saveimg(self, data):
		if self.AlbumCover == '' or len(data) == 0: return
		fobj = open(self.AlbumCover,"w")
		fobj.write(data)
		fobj.close()
		self.Result = True

	def cb(self, itm, artist, album, result, *args):
		data = self.engine.get_best_match_urls(result)
		if data and data[0] and self.artist == artist and self.album == album:
			self.loader.get_url(data[0], self.saveimg)

	def run(self):
		if os.path.exists(self.AlbumCover): os.remove(self.AlbumCover)
		self.Result = False
		self.engine.search (self.artist, self.album, self.cb)
		while True:
			if self.Result: 
				break
			if not self.engine.search_next ():
				break

		cover = False
		if os.path.exists(self.AlbumCover):
			cover = self.AlbumCover

		#print threading.currentThread()
		self.callback_fn(cover)
		return None

# ------------------------------------------------------------------------------

#
# Copyright (C) 2006 - Gareth Murphy, Martin Szulecki
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301  USA.

from xml.dom import minidom
import re
import locale
import urllib

LICENSE_KEY    = "18C3VZN9HCECM5G3HQG2"
DEFAULT_LOCALE = "en_US"

class Bag: pass

class AmazonCoverArtSearch (object):
	def __init__ (self, loader):
		self.searching = False
		self.cancel = False
		self.loader = loader
		self._supportedLocales = {
			"en_US" : ("us", "xml.amazon.com"),
			"en_GB" : ("uk", "xml-eu.amazon.com"),
			"de" : ("de", "xml-eu.amazon.com"),
			"ja" : ("jp", "xml.amazon.co.jp")
		}

	def __get_locale (self):
		default = locale.getdefaultlocale ()
		lc_id = DEFAULT_LOCALE
		if default[0] is not None:
			if self._supportedLocales.has_key (default[0]):
				lc_id = default[0]

		lc_host = self._supportedLocales[lc_id][1]
		lc_name = self._supportedLocales[lc_id][0]
		return ((lc_host, lc_name))

	def search (self, artist, album, on_search_completed_callback, *args):
		self.searching = True
		self.cancel = False
		self.on_search_completed_callback = on_search_completed_callback
		self.args = args
		self.keywords = []

		self.album = album
		self.artist = artist

		st_artist = artist or "Unknown"
		st_album = album or "Unknown"

		# Tidy up

		# Replace quote characters
		# don't replace single quote: could be important punctuation
		for char in ["\""]:
			st_artist = st_artist.replace (char, '')
			st_album = st_album.replace (char, '')


		self.st_album = st_album
		self.st_artist = st_artist

		# Remove variants of Disc/CD [1-9] from album title before search
		for exp in ["\([Dd]isc *[1-9]+\)", "\([Cc][Dd] *[1-9]+\)"]:
			p = re.compile (exp)
			st_album = p.sub ('', st_album)

		st_album_no_vol = st_album
		for exp in ["\(*[Vv]ol.*[1-9]+\)*"]:
			p = re.compile (exp)
			st_album_no_vol = p.sub ('', st_album_no_vol)

		self.st_album_no_vol = st_album_no_vol

		# Save current search's properties
		self.search_album = st_album
		self.search_artist = st_artist
		self.search_album_no_vol = st_album_no_vol
		
		# TODO: Improve to decrease wrong cover downloads, maybe add severity?
		# Assemble list of search keywords (and thus search queries)
		if st_album == "Unknown":
			self.keywords.append ("%s Best of" % (st_artist))
			self.keywords.append ("%s Greatest Hits" % (st_artist))
			self.keywords.append ("%s Essential" % (st_artist))
			self.keywords.append ("%s Collection" % (st_artist))
			self.keywords.append ("%s" % (st_artist))
		elif st_artist == "Unknown":
			self.keywords.append ("%s" % (st_album))
			if st_album_no_vol != st_artist:
				self.keywords.append ("%s" % (st_album_no_vol))
			self.keywords.append ("Various %s" % (st_album))
		else:
			if st_album != st_artist:
				self.keywords.append ("%s %s" % (st_artist, st_album))
				if st_album_no_vol != st_album:
					self.keywords.append ("%s %s" % (st_artist, st_album_no_vol))
				if (st_album != "Unknown"):
					self.keywords.append ("Various %s" % (st_album))
			self.keywords.append ("%s" % (st_artist))

		# Initiate asynchronous search
		self.search_next ();

	def __build_url (self, keyword):
		try:
			(lc_host, lc_name) = self.__get_locale ()
		
			url = "http://" + lc_host + "/onca/xml?Service=AWSECommerceService"
			url += "&SubscriptionId=" + LICENSE_KEY
			url += "&Operation=ItemSearch"
			url += "&SearchIndex=Music"
			url += "&ResponseGroup=ItemAttributes,Images"
			url += "&type=lite"
			url += "&Keywords=" + urllib.quote (keyword)

			return url
		except:return None

	def search_next (self):
		self.searching = True
		
		if len (self.keywords)==0:
			keyword = None
		else:
			keyword = self.keywords.pop (0)

		if keyword is None:
			# No keywords left to search -> no results
			self.on_search_completed (None)
			ret = False
		else:
			# Retrieve search for keyword
			url = self.__build_url (keyword.strip ())
			if url != None:
				self.loader.get_url (url, self.on_search_response)
				ret = True
			else:
				ret = False

		return ret

	def __unmarshal (self, element):
		rc = Bag ()
		childElements = [e for e in element.childNodes if isinstance (e, minidom.Element)]
		if childElements:
			for child in childElements:
				key = child.tagName
				if hasattr (rc, key):
					if type (getattr (rc, key)) <> type ([]):
						setattr (rc, key, [getattr (rc, key)])
					getattr (rc, key).append(self.__unmarshal(child))
				else:
					setattr (rc, key, [self.__unmarshal(child)])
		else:
			rc = "".join ([e.data for e in element.childNodes if isinstance (e, minidom.Text)])
			if element.tagName == 'SalesRank':
				rc = rc.replace ('.', '')
				rc = rc.replace (',', '')
				rc = int (rc)
		return rc

	def on_search_response (self, result_data):
		if result_data is None:
			self.search_next()
			return

		try:
			xmldoc = minidom.parseString (result_data)
		except:
			self.search_next()
			return
		
		valid = False
		try:
			data = self.__unmarshal(xmldoc).ItemSearchResponse[0].Items[0]
			valid = data.Request[0].IsValid[0].lower() == "true" and int(data.TotalResults[0]) > 0
		except: pass
		
		if not valid:
			# Search was unsuccessful, try next keyword
			self.search_next ()
		else:
			# We got some search results
			self.on_search_results (data.Item)

	def on_search_results (self, results):
		self.on_search_completed (results)

	def on_search_completed (self, result):
		self.on_search_completed_callback (self, self.artist, self.album, result, *self.args)
		self.searching = False

	def __tidy_up_string (self, s):
		# Lowercase
		s = s.lower ()
		# Strip
		s = s.strip ()

		# TODO: Convert accented to unaccented
		s = s.replace (" - ", " ")	
		s = s.replace (": ", " ")
		s = s.replace (" & ", " and ")

		return s

	def get_best_match_urls (self, search_results):
		# Default to "no match", our results must match our criteria
		best_match = None

		try:
			if self.search_album != "Unknown":
				album_check = self.__tidy_up_string (self.search_album)
				for item in search_results:
					# Check for album name in ProductName
					try: product_name = self.__tidy_up_string (item.ItemAttributes[0].Title[0])
					except: product_name = ''

					if product_name == album_check:
						# Found exact album, can not get better than that
						best_match = item
						break
					# If we already found a best_match, just keep checking for exact one
					elif (best_match is None) and (product_name.find (album_check) != -1):
						best_match = item

			# If we still have no definite hit, use first result where artist matches
			if (self.search_album == "Unknown" and self.search_artist != "Unknown"):
				artist_check = self.__tidy_up_string (self.search_artist)
				if best_match is None:
					# Check if artist appears in the Artists list
					hit = False
					for item in search_results:
						try: artists = item.ItemAttributes[0].Artist
						except: artists = []
						
						for artist in artists:
							artist = self.__tidy_up_string (artist)
							if artist.find (artist_check) != -1:
								best_match = item
								hit = True
								break
						if hit:
							break

			if best_match:
				try: large = best_match.LargeImage[0].URL[0]
				except: large = ''
				try: medium = best_match.MediumImage[0].URL[0]
				except: medium = ''
				return [large, medium]
			else:
				return []

		except TypeError:
			return []
